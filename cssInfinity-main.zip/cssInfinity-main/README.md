Infinity | CSS Only Animation Effects

https://ozllmozdmrr.github.io/cssInfinity/
