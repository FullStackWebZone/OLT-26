# digitalClock
Analog and Digital Clock Design using Html CSS & Javascript
![image](https://user-images.githubusercontent.com/66878884/163491984-3c5bded6-1e86-45bd-a2cf-72d3c0d3c6e5.png)
