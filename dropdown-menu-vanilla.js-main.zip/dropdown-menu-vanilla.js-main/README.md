# dropdown-menu-vanilla.js
This repository contents a dropdown menu using html, css and Vanilla JavaScript.

Link to live content: https://dropdown-menu-vanilla-js.vercel.app/
