# floating-action-menu
An animated user menu

### Demo:
https://liyannguyen.github.io/floating-action-menu/
