let btn = document.querySelector('.btn');
btn.onclick = function() {
    btn.classList.toggle('active')
}